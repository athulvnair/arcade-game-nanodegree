frontend-nanodegree-arcade-game
===============================

*) The main aim of this game is to cross the gray tiles to the blue tiles without colliding any bugs. The players score increases each time he completes a level and the number of enemy bugs also increases for each level.

*) The game only uses simple control of just 4 command buttons. Which are left/up/right/down to navigate the player.

*) To access the game one only needs to open the index.html file using any of the modern day web browser.

*) JS files :
only the app.js file has been edited while the rest javascript, css & html files were already provided from the course provider.
